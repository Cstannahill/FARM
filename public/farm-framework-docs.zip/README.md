# FARM Framework Documentation Bundle

Generated on: 2025-06-13T01:55:30.264Z
Format: Complete documentation archive for AI/ML context

## Contents

This bundle contains the complete FARM Framework documentation in markdown format,
optimized for use with AI assistants, vector databases, and offline reference.

### Structure

- `docs/` - Core framework documentation
- `guides/` - Step-by-step tutorials and guides  
- `api/` - API reference documentation
- `advanced/` - Advanced topics and architecture
- `community/` - Community resources and examples
- `meta/` - Metadata and framework information

### Usage with AI Tools

This documentation bundle is specifically formatted for:

- **Vector Database Ingestion** - Clean markdown for embedding
- **RAG (Retrieval Augmented Generation)** - Structured for context retrieval
- **AI Assistant Context** - Comprehensive framework knowledge
- **Plugin Development** - Complete API and architecture reference

### Framework Information

- **Name:** FARM Framework
- **Description:** AI-first full-stack framework combining React, FastAPI, and MongoDB
- **Repository:** https://github.com/cstannahill/farm-framework
- **Documentation:** https://farm-framework.com
- **Version:** 2.0+

## Getting Started with FARM

1. **Installation:** `npx create-farm-app my-app`
2. **Development:** `farm dev`
3. **AI Integration:** Built-in support for OpenAI, Ollama, Hugging Face
4. **Deployment:** `farm deploy`

For the latest updates and community resources, visit https://farm-framework.com
